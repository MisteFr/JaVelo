package ch.epfl.javelo;

import java.io.IOException;
import java.nio.LongBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;

public class Main {

    public static void main(String[] args) {

        float[] samples = new float[4];
        int SAMPLE_NUMBER = 4;
        float[] test = {0, Float.NaN, 7.989F, 88};

        for (int i = 0; i < SAMPLE_NUMBER; ++i){ //Est-ce que ça peut juster renvoyer NaN ?
            samples[i] = test[i]; //TODO pourquoi est ce que j'ai besoin de caster ici ?
        }
        for(int j = 0; j < 4; ++j){
            System.out.println(samples[j]);
        }
    }
}
