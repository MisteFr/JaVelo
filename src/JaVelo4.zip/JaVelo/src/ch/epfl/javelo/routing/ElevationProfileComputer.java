package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

public final class ElevationProfileComputer {

    //Non-instantiable class
    private ElevationProfileComputer(){}

    public static ElevationProfile elevationProfile(Route route, double maxStepLength){ //TODO: s'arranger pour utiliser ceilDiv de Math2 ?

        Preconditions.checkArgument(maxStepLength > 0);

        final int SAMPLE_NUMBER = (int) Math.ceil((route.length()/maxStepLength)) + 1;
        final float STEP_LENGTH = (((float) route.length())/((float) (SAMPLE_NUMBER - 1))); //La distance qui correspond à un step basée sur la longueur totale de l'itinéraire (il y a un step de moins qu'il n'y a de points) TODO vérifier.
        float[] samples = new float[SAMPLE_NUMBER];

        for (int i = 0; i < SAMPLE_NUMBER; ++i){ //Est-ce que ça peut juster renvoyer NaN ?
            samples[i] = (float) route.elevationAt(i*STEP_LENGTH); //TODO pourquoi est ce que j'ai besoin de caster ici ?
        }

        

        return new ElevationProfile(route.length(), samples);
    }
}
